#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "logger.h"

void logger(const char* tag, const char* fmt, ...) {
	time_t now;
	time(&now);
	FILE* fp;

	fp = fopen("/tmp/i2c_log.txt", "a+");
	if (fp != NULL) {
		va_list argp;
		
		va_start(argp, fmt);
		fprintf(fp, "\n\n%s [%s]:\n ", ctime(&now), tag);
		fprintf(fp, fmt, argp);
		va_end(argp);
		fflush(fp);
		fclose(fp);
	}
}
