#ifndef LOGGER_H
#define LOGGER_H

void logger(const char* tag, const char* fmt, ...);

#endif /* LOG_H */
