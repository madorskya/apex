//#include <stdio.h>
//#include <stdint.h>
//#include <stdlib.h>
//#include <unistd.h>
#include "toml.h"
//#include "string.h"

int main() {
	FILE* fp;
	char errbuf[1000];
	char* g;
	long long int* f;
	int hex;
	long long int a;
	long long int b;
	long long int c;
	long long int d;
	long long int e;

	/* Open the file. */
	fp = fopen("/root/send/test.toml", "r");
	toml_table_t* config;
	toml_table_t* test;

	config = toml_parse_file(fp, errbuf, sizeof(errbuf));

	fclose(fp);

	test = toml_table_in(config, "TEST");

	toml_array_t* arr;
	toml_raw_t raw;

	raw = toml_raw_in(test, "e");
	toml_rtoi(raw, &e);

	raw = toml_raw_in(test, "a");
	toml_rtoi(raw, &a);

	raw = toml_raw_in(test, "b");
	toml_rtoi(raw, &b);

	raw = toml_raw_in(test, "c");
	toml_rtoi(raw, &c);

	raw = toml_raw_in(test, "d");
	toml_rtoi(raw, &d);

	//raw = toml_raw_in(test, "e");
	//toml_rtoi(raw, &e);

	/*arr = toml_array_in(test, "a");
	raw = toml_raw_at(arr, 0);
	toml_rtoi(raw, &a[0]);

	arr = toml_array_in(test, "b");
	raw = toml_raw_at(arr, 0);
	toml_rtoi(raw, &b[0]);

	arr = toml_array_in(test, "c");
	raw = toml_raw_at(arr, 0);
	toml_rtoi(raw, &c[0]);

	arr = toml_array_in(test, "d");
	raw = toml_raw_at(arr, 0);
	toml_rtoi(raw, &d[0]);

	arr = toml_array_in(test, "e");
	raw = toml_raw_at(arr, 0);
	toml_rtoi(raw, &e[0]);*/

	arr = toml_array_in(test, "f");
	raw = toml_raw_at(arr, 0);
	toml_rtoi(raw, &f[0]);

	raw = toml_raw_at(arr, 1);
	toml_rtoi(raw, &f[1]);

	raw = toml_raw_in(test, "g");
	toml_rtos(raw, &g);

	//raw = toml_raw_in(test, "h");
	//toml_rtoi(raw, &h);

	//printf("0x%x\n", hex);
	printf("0x%llx\n", a);
	printf("%lld\n", b);
	printf("%lld\n", c);
	printf("%lld\n", d);
	printf("%lld\n", e);
	printf("%lld\n", f[0]);
	printf("%lld\n", f[1]);
	printf("%s\n", g);
	//printf("%d\n", h);

	toml_free(config);

	return 0;
}
