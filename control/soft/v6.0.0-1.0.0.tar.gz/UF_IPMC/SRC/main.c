/*
-------------------------------------------------------------------------------
coreIPM/main.c

Author: Gokhan Sozmen
-------------------------------------------------------------------------------
Copyright (C) 2007-2008 Gokhan Sozmen
-------------------------------------------------------------------------------
coreIPM is free software; you can redistribute it and/or modify it under the 
terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later 
version.

coreIPM is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with 
coreIPM; if not, write to the Free Software Foundation, Inc., 51 Franklin
Street, Fifth Floor, Boston, MA 02110-1301, USA.
-------------------------------------------------------------------------------
See http://www.coreipm.com for documentation, latest information, licensing, 
support and contact details.
-------------------------------------------------------------------------------
*/
#include "ipmi.h"
#include "debug.h"
#include "ws.h"
#include "timer.h"
//#include "gpio.h"
#include "ipmc.h"
//#include "serial.h"
#include "i2c.h"
#include "i2c-sensor.h"
//#include "iopin.h"
#include "picmg.h"
#include "toml.h"

extern unsigned long long int lbolt;
//extern void *devmem_ptr;
/*==============================================================
 * main()
 *==============================================================*/
int main()
{
	unsigned long time;
	//unsigned int act = 1;

	/* Initialize system */
	ws_init();
    	//iopin_initialize();
    	//gpio_initialize();
	timer_initialize();
	//toml_config_initialize();
	i2c_initialize();
	i2c_sensor_initialize();
    	//uart_initialize();
	//ipmi_initialize();
	module_init();
	//module_sensor_init();    
	//fru_data_init();
	//adc_init_sensor_record();
	

        dbprintf( DBG_I2C | DBG_LVL1, "Hello World\n");
	
        time = lbolt;

	//picmg_m1_state( 0 );
	
	/* Do forever */
	while( 1 )
	{
		/* Blink system activity LEDs once every second */
        /*if( ( time + 2 ) < lbolt ) {
			time = lbolt;
			gpio_toggle_activity_led();
        }*/
		ws_process_work_list_0();
		//usleep(500000);
		ws_process_work_list_1();
		//usleep(500000);
        //terminal_process_work_list();
		timer_process_callout_queue();
	}
	i2c_deinitialize();
	i2c_sensor_deinitialize();
	//toml_free(config);
}

