#ifndef LOGGER_H
#define LOGGER_H

void logger(const char* tag, const char* message);

#endif /* LOG_H */
