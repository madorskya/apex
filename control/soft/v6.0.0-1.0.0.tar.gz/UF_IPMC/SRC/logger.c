#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "logger.h"

void logger(const char* tag, const char* message) {
	time_t now;
	time(&now);
	FILE* fp;

	fp = fopen("/tmp/i2c_log.txt", "a+");
	if (fp != NULL) {
		fprintf(fp, "%s [%s]: %s\n", ctime(&now), tag, message);
		fflush(fp);
		fclose(fp);
	}
}
