#include <stdio.h>
#include <stdlib.h>
#include "i2c-sensor.h"

extern int i2c_fd_snsr[];

int main()
{
	char result;

	i2c_sensor_initialize();

	i2c_read(i2c_fd_snsr[0], 0x48, 0x00, &result);

	//i2c_read(0x48, 0x00, &result);

	printf("%d\n", result);

	i2c_sensor_deinitialize();

	return 0;
}
