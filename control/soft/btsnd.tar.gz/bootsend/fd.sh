strings 7z015.bit | grep -A1 2020
