//#pragma once

/*==============================================================*/
/* I2C 7-BIT ADDRESSING 					*/
/*==============================================================*/

#define I2C_ADDRESS_LOCAL	0
#define I2C_ADDRESS_REMOTE	1

//#define I2C_NUM_CHANNELS	2

/* Channel utilization policies */
//#define CH_POLICY_0_ONLY	0x0
//#define CH_POLICY_1_ONLY	0x1
//#define CH_POLICY_ALL		0x2

extern int repeat;
extern int i2c_fd_0;
extern int i2c_fd_1;
extern int devmem_fd;
extern void *devmem_ptr;

/*==============================================================*/
/* Function Prototypes						*/
/*==============================================================*/
void i2c_initialize( void );
void i2c_deinitialize( void );

//void i2c_interface_enable_local_control( unsigned char channel, unsigned char link_id );
//void i2c_interface_disable( unsigned char channel, unsigned char link_id );
void i2c_master_write_0( IPMI_WS *ws );
void i2c_master_write_1( IPMI_WS *ws );
void i2c_slave_read_0( void );
void i2c_slave_read_1( void );
void i2c_set_slave_receive_callback( void ( *callback_fn )( void *, int ) );
void reg_write(void *reg_base, unsigned int offset, unsigned int value);
unsigned int reg_read(void *reg_base, unsigned int offset);
