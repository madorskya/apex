"xvcServer.c", is a derivative of "xvcd.c" (https://github.com/tmbinc/xvcd) 
by tmbinc, used under CC0 1.0 Universal (http://creativecommons.org/publicdomain/zero/1.0/). 
"xvcServer.c" is licensed under CC0 1.0 Universal (http://creativecommons.org/publicdomain/zero/1.0/) 
by Avnet and is used by Xilinx for XAPP1251.

Note that this version of xvcServer.c will not be updated going forward to keep this source code
tightly coupled with XAPP1251.  See `src/user/` for the xvcServer.c source code that is still in
active development.
