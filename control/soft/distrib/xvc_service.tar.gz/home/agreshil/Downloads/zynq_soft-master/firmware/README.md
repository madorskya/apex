7z015_two_jtag_bridges.bit - Zynq board PL firmware with two JTAG debug bridges. Rename to 7z015.bit when installing from SD card 
