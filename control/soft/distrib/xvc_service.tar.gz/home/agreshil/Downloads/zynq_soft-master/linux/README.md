zynq-7000.dtsi - modified device tree file with added two jtag debug bridge devices
Copy this file to Zynq {KERNEL_SRC}/arch/arm/boot/dts and recompile DTBs from {KERNEL_SRC}
'make ARCH=arm CROSS_COMPILE=arm-xilinx-linux-gnueabi- dtbs'

interfaces - minimal network configuration file for eth0 Gigabit ethernet interface with static IP, directly connected to host computer
Copy it on Zynq device in /etc/network/interfaces 

dropbear_key_gen.sh - script to generate SSH server side keys for dropbear SSH tools

