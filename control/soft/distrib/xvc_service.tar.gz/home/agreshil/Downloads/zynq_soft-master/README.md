# zynq

Xilinx Zynq 7000 software for CSC trigger projects